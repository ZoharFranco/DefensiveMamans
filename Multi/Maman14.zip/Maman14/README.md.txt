Client:
Client directory contains all client project files;
In order to run client you have to run the main.py file, client.py contains the client class logic.

Server:
Server directory contains all server project files.
In order to run server you have build the project, all clion files are in the directory, also the auto make file is in.
After building the project you can run the main.exe file.