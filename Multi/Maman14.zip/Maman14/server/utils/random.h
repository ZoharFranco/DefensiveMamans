#include <iostream>
#include <fstream>
#include <random>
#include <string>

// Function to generate a random 32-character file name
std::string generate_file_name(size_t length);