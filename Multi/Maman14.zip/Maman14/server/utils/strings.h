//
// Created by HPC on 29/08/2024.
//

#ifndef SERVER_STRINGS_H
#define SERVER_STRINGS_H

std::vector<char> getCharsFromLines(const std::vector<std::string>& lines);

#endif //SERVER_STRINGS_H
